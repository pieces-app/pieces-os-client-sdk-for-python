# PrivacyEnum

OPEN: Means that privacy is fully open CLOSED: Means that privacy is fully locked down, and private ANONYMOUS: Means that we are allowed to collect information but it cannot get attached to me as the user.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


