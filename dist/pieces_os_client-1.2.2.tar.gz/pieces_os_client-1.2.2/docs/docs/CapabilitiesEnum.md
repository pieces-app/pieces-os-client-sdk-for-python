# CapabilitiesEnum

This lets us know what capabilites in relation to ml/ cloud infrastructure you are opting into.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


