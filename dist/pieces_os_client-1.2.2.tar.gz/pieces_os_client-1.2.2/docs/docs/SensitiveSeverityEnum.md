# SensitiveSeverityEnum

This is the enum used to describe the severity of our sensitive model. ie low, moderate, high

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


