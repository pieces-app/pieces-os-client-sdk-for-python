# ConversationMessageSentimentEnum

This will describe the sentiment of a specific message ie if the message was liked/disliked/reported

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


